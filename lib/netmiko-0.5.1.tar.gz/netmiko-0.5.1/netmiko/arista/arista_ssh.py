from netmiko.ssh_connection import SSHConnection


class AristaSSH(SSHConnection):
    pass
