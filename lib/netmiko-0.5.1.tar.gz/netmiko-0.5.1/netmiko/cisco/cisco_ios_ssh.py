from netmiko.ssh_connection import SSHConnection


class CiscoIosSSH(SSHConnection):
    pass
